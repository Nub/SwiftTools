// Playground - noun: a place where people can play

import Cocoa

func foo(done: ((String) -> Void), bar: String = "default"){
	done(bar)
}

// It works!, but what if I want to set bar?
foo(){(bar: String) in
	println(bar)
}

// No workie
//foo(bar: "test"){(bar: String) in
//	println(bar)
//}

// Ugh I guess rewrite, but works
foo({(bar: String) in
	println(bar)
}, bar: "test")



func foo2(bar: String = "z", done: ((String) -> Void)){
	done(bar)
}

// No workie
//foo2(){(bar: String) in
//	println(bar)
//}

// Works now, but still not usage of defaults
foo2(bar: "test2"){(bar: String) in
	println(bar)
}


func foo3(bar: String = "z", _ done: ((String) -> Void) = {x in println("default")}
	){
	done(bar)
}

// No workie
//foo3(){(bar: String) in
//	println(bar)
//}

// Works, but no default value
foo3(bar: "test3"){(bar: String) in
	println(bar)
}

// Works, but useless
foo3()
foo3(bar: "test4")
